/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betterware.models;

import java.math.BigDecimal;

/**
 *
 * @author Ainz Oal Gown
 */

    

public class Pedidos {
    private int id;                      // INT AUTO_INCREMENT PRIMARY KEY
    private String codigo;               // VARCHAR(100) NOT NULL
    private String producto;             // VARCHAR(255) NOT NULL
    private BigDecimal precioCompra;     // DECIMAL(10,2) DEFAULT NULL
    private String fecha;                // VARCHAR(20)
    private int cantidad;                // INT DEFAULT 0
    private String nombreCliente;        // VARCHAR(40)

    public Pedidos(int id, String codigo, String producto, BigDecimal precioCompra,
        String fecha, int cantidad, String nombreCliente) {
            this.id = id;
            this.codigo = codigo;
            this.producto = producto;
            this.precioCompra = precioCompra;
            this.fecha = fecha;
            this.cantidad = cantidad;
            this.nombreCliente = nombreCliente;
        }

    public int getId() {
        return id; 
    }
    public void setId(int id) { this.id = id; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getProducto() { return producto; }
    public void setProducto(String producto) { this.producto = producto; }
    public BigDecimal getPrecioCompra() { return precioCompra; }
    public void setPrecioCompra(BigDecimal precioCompra) { this.precioCompra = precioCompra; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public String getNombreCliente() { return nombreCliente; }
    public void setNombreCliente(String nombreCliente) { this.nombreCliente = nombreCliente; }
}

