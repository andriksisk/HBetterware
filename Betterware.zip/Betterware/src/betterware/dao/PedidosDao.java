/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betterware.dao;

import betterware.models.Pedidos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ainz Oal Gown
 */
public class PedidosDao {
    public List<Pedidos> obtenerPedidos() {
        List<Pedidos> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedidos";

        try (Connection conn = ConexionDB.conectar();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Pedidos p = new Pedidos(
                    rs.getInt("id"),
                    rs.getString("codigo"),
                    rs.getString("producto"),
                    rs.getBigDecimal("precio_compra"),
                    rs.getString("fecha"),
                    rs.getInt("cantidad"),
                    rs.getString("nombre_Cliente")
                );
                lista.add(p);
            }

        } catch (SQLException e) {
            System.out.println("❌ Error al cargar pedidos: " + e.getMessage());
        }
        return lista;
    }
    public boolean eliminarPedido(int id) {
        String sql = "DELETE FROM pedidos WHERE id = ?";
        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            int filas = stmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            System.out.println("❌ Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }
}
