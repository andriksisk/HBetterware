/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package betterware.controllers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.RadioMenuItem;
import javafx.scene.control.ToggleGroup;

/**
 * FXML Controller class
 *
 * @author manac
 */
public class AccionAgregarControllerController implements Initializable {
    @FXML
    private RadioMenuItem PromCasitaPlus;
    @FXML
    private RadioMenuItem PromHiper;
    @FXML
    private RadioMenuItem PromBetterLow;
    @FXML
    private RadioMenuItem NoProm;
    @FXML
    private RadioMenuItem PromCasita;
    @FXML
    private ToggleGroup groupPromocion;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        PromCasitaPlus.setToggleGroup(groupPromocion);
        PromHiper.setToggleGroup(groupPromocion);
        PromBetterLow.setToggleGroup(groupPromocion);
        NoProm.setToggleGroup(groupPromocion);
        PromCasita.setToggleGroup(groupPromocion);
        
    }    
    
}
