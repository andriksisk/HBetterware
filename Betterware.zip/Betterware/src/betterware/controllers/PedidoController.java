/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package betterware.controllers;

import betterware.aux.ItemFila;
import betterware.models.Producto;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 *
 * @author Ainz Oal Gown
 */
public class PedidoController implements Initializable {
    
    private TablaPrincipalController tablaPrincipalController;
    @FXML
    private TableView<ItemFila> tablaPedido;

    @FXML
    private TableColumn<ItemFila, Integer> colId;

    @FXML
    private TableColumn<ItemFila, String> colNombre;

    @FXML
    private TableColumn<ItemFila, Integer> colCantidad;

    @FXML
    private TableColumn<ItemFila, BigDecimal> colPrecio;

    @FXML
    private Button CancelarBoton;
    private ObservableList<ItemFila> filas;
    @FXML
    private TextField txtTotal;
    
    @FXML
    private Button btnAgregarFila;

    @FXML
    private Button btnEliminarFila;

        
    public void setTablaPrincipalController(TablaPrincipalController controller) {
        this.tablaPrincipalController = controller;
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        filas = FXCollections.observableArrayList();

        colId.setCellValueFactory(cd -> cd.getValue().idProperty().asObject());
        colNombre.setCellValueFactory(cd -> cd.getValue().nombreProperty());
        colCantidad.setCellValueFactory(cd -> cd.getValue().cantidadProperty().asObject());
        colPrecio.setCellValueFactory(cd -> cd.getValue().precioTotalProperty());

        tablaPedido.setItems(filas);

        // Primera fila vacía
        filas.add(new ItemFila());
        
        ////////////////////
        colId.setCellFactory(col -> new TableCell<ItemFila, Integer>() {
            @Override
            protected void updateItem(Integer value, boolean empty) {
                super.updateItem(value, empty);
                if (empty || value == null || value == 0) {
                    setText("");
                } else {
                    setText(String.valueOf(value));
                }
            }
        });

        /*colCantidad.setCellFactory(col -> new TableCell<ItemFila, Integer>() {
            @Override
            protected void updateItem(Integer value, boolean empty) {
                super.updateItem(value, empty);
                if (empty || value == null || value == 0) {
                    setText("");
                } else {
                    setText(String.valueOf(value));
                }
            }
        });*/

        colPrecio.setCellFactory(col -> new TableCell<ItemFila, BigDecimal>() {
            @Override
            protected void updateItem(BigDecimal value, boolean empty) {
                super.updateItem(value, empty);
                if (empty || value == null || value.compareTo(BigDecimal.ZERO) == 0) {
                    setText("");
                } else {
                    setText(value.toString());
                }
            }
        });
        
        /////////////////
        colCantidad.setCellFactory(col -> new TableCell<ItemFila, Integer>() {

            private final Spinner<Integer> spinner = new Spinner<>(); // se crea solo una vez
            private boolean initialized = false;

            {
                spinner.setEditable(false);
                spinner.setPrefWidth(90);

                // Listener del spinner SOLO una vez
                spinner.valueProperty().addListener((obs, oldVal, newVal) -> {
                    ItemFila fila = getTableRow() != null ? getTableRow().getItem() : null;

                    if (fila != null && newVal != null && fila.getId() != 0) {
                        fila.setCantidad(newVal);
                        aplicarPromocionAFila(fila);
                        tablaPedido.refresh();
                        recalcularTotalGeneral();
                    }
                });
            }

            @Override
            protected void updateItem(Integer val, boolean empty) {
                super.updateItem(val, empty);

                if (empty || getTableRow() == null || getTableRow().getItem() == null) {
                    setGraphic(null);
                    return;
                }

                ItemFila fila = getTableRow().getItem();

                // filas vacías no deben mostrar spinner
                if (fila.getId() == 0 || fila.getProducto() == null) {
                    setGraphic(null);
                    return;
                }

                int max = fila.getMaxCantidad();
                if (max < 1) max = 1;

                int current = fila.getCantidad();
                if (current < 1) current = 1;
                if (current > max) current = max;

                spinner.setValueFactory(
                    new SpinnerValueFactory.IntegerSpinnerValueFactory(1, max, current)
                );

                setGraphic(spinner);
            }
        });

    }
   
    private void recalcularTotalGeneral() {
        BigDecimal total = filas.stream()
                .filter(f -> f.getId() != 0) // ignorar fila vacía
                .map(ItemFila::getPrecioTotal)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        txtTotal.setText(total.setScale(2, RoundingMode.HALF_UP).toString());
    }
    
    @FXML
    private void agregarProductoDesdeBoton() {
        // busca la fila vacía (la que tiene id == 0)
        ItemFila filaVacia = filas.stream().filter(f -> f.getId() == 0).findFirst().orElse(null);

        if (filaVacia == null) {
            filaVacia = new ItemFila();
            filas.add(filaVacia);
        }

        abrirSelectorDeProductos(filaVacia);
    }
    @FXML
    private void eliminarFilaSeleccionada() {
        ItemFila seleccionada = tablaPedido.getSelectionModel().getSelectedItem();

        if (seleccionada == null) return;

        // no eliminar la fila vacía
        if (seleccionada.getId() == 0) return;

        filas.remove(seleccionada);

        // asegurar fila vacía siempre
        if (filas.stream().noneMatch(f -> f.getId() == 0))
            filas.add(new ItemFila());

        tablaPedido.refresh();
        recalcularTotalGeneral();
    }

    private void agregarProducto(ItemFila fila) {
        tablaPedido.refresh();
        abrirSelectorDeProductos(fila);
        
    }
    
    private void abrirSelectorDeProductos(ItemFila itemFila) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/betterware/tablaPrincipal.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Seleccionar producto");
            stage.setScene(new Scene(root));

            TablaPrincipalController selectorController = loader.getController();

            selectorController.setOnProductoSeleccionado(producto -> {
                // Rellenar la misma ItemFila que se pasó
                itemFila.setProducto(producto);
                itemFila.setCantidad(1);
                itemFila.setPrecioUnitario(producto.getPrecio_estandar());
                itemFila.setMaxCantidad(producto.getCantidad());

                // Aplicar promo a esa fila y se refresca
                aplicarPromocionAFila(itemFila);

                // Asegurar que haya siempre una fila vacía disponible
                boolean existeFilaVacia = filas.stream().anyMatch(f -> f.getId() == 0);
                if (!existeFilaVacia) {
                    filas.add(new ItemFila());
                }

                tablaPedido.refresh();
                recalcularTotalGeneral();

                // cerrar selector
                Platform.runLater(stage::close);
            });

            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    
    //promociones
    private void aplicarPromocionAFila(ItemFila fila) {
        Producto p = fila.getProducto();
        if (p == null) return;

        int qty = fila.getCantidad();
        BigDecimal unitStd = p.getPrecio_estandar() == null ? BigDecimal.ZERO : p.getPrecio_estandar();
        BigDecimal unitPromo = p.getPrecio_promocion() == null ? unitStd : p.getPrecio_promocion();

        String promo = p.getPromocion() == null ? "" : p.getPromocion().trim();

        BigDecimal totalFila = BigDecimal.ZERO;

        switch (promo) {
            case "Mega Oferta":
                // promo aplica si qty >= 3 y el producto está marcado como 'nuevo'
                if (qty >= 3 && p.isNuevo()) {
                    totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                } else {
                    totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                }
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            case "Casita":
                // promo individual: si compra 3 o más de ese producto == promo
                if (qty >= 3) totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                else totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            case "Casita Premium":
                //Si compra 5+ → precio promocional
                if (qty >= 5) totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                else totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;
                
            case "Híper Oferta":
            case "HÍPER OFERTA":
            case "HIPER OFERTA":
                //se aplica si se compra 1 de casita
                // Aquí ponemos comportamiento por defecto: si producto está marcado con Híper, aplicar promo
                if (qty >= 1) totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                else totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            case "BetterLocura":
            case "Better Locura":
                // si qty >=2 y el producto pertenece a la sección Better Locura
                if (qty >= 2) totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                else totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            case "Precio Rojo":
            case "PRECIO ROJO":
                // requiere validar 2+ productos en el pedido que sean Precio Rojo y misma categoría
                // por fila lo ponemos así: si esta fila qty>=2 == promo; si quieres cross-product:
                long countMismoPromoYCategoria = filas.stream()
                        .filter(f -> f.getProducto() != null)
                        .filter(f -> "Precio Rojo".equalsIgnoreCase(f.getProducto().getPromocion()))
                        .filter(f -> f.getProducto().getCategoria() != null && f.getProducto().getCategoria().equalsIgnoreCase(p.getCategoria()))
                        .mapToInt(ItemFila::getCantidad)
                        .sum();
                if (countMismoPromoYCategoria >= 2) {
                    totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                } else {
                    totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                }
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            case "Descuento Estandar":
            case "Descuento estándar":
                // siempre aplicar promo
                totalFila = unitPromo.multiply(BigDecimal.valueOf(qty));
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            case "Lleva el segundo a":
            case "Lleva el segundo a...":
                // aplica promoción sólo a la segunda unidad
                if (qty >= 2) {
                    BigDecimal segunda = unitPromo;                // precio promocional para segunda
                    BigDecimal resto = unitStd.multiply(BigDecimal.valueOf(qty - 1));
                    totalFila = segunda.add(resto);
                } else {
                    totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
                }
                System.out.println(
                    "PROMO[" + promo + "] Producto: " + p.getProducto() +
                    " | Qty=" + qty +
                    " | unitStd=" + unitStd +
                    " | unitPromo=" + unitPromo +
                    " | total=" + totalFila +
                    " | APLICADA=" + (totalFila.compareTo(unitStd.multiply(BigDecimal.valueOf(qty))) != 0)
                );
                break;

            default:
                // sin promo o promo no reconocida == precio estándar
                totalFila = unitStd.multiply(BigDecimal.valueOf(qty));
        }

        fila.setPrecioTotal(totalFila);
    }

    private void eliminarFila(ItemFila fila) {
        filas.remove(fila);

        if (filas.isEmpty()) {
            filas.add(new ItemFila()); // nunca debe quedar sin filas
        }
    }
    
    @FXML 
    private void CancelarBton() {
        Stage stage = (Stage) CancelarBoton.getScene().getWindow();
        stage.close();
    }
}

/* Método para guardar la sección de Pedidos. Poner el nombre del método en el botón "onAction#GuardarBton"
    
    @FXML
    private void GuardarBton(){
    }
    */