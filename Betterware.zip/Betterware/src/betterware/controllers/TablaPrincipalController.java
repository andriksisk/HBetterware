 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package betterware.controllers;

import betterware.dao.PedidosDao;
import betterware.dao.ProductosDao;
import betterware.models.Pedidos;
import betterware.models.Producto;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class TablaPrincipalController implements Initializable {

    @FXML
    private TableView<Object> ProductosView;//cambiar nombre a tabla principal
    
    @FXML 
    private ToggleButton switchModo;
    @FXML
    private boolean modoPedidos = false;
    
    @FXML
    private Button agregarBton;
    @FXML
    private Button EditarBoton;
    @FXML 
    private Button EliminarBoton;

    private ObservableList<Object> listaProductos;
    private ObservableList<Object> listaPedidos;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarProductos(); // se ejecuta al iniciar
        switchModo.setOnAction(e -> cambiarModo());
    }
    
    @FXML
    private void cambiarModo() {
        modoPedidos = switchModo.isSelected();

        if (modoPedidos) {
            switchModo.setText("Modo Pedidos");
            cargarPedidos();
            configurarBotonesParaPedidos();
        } else {
            switchModo.setText("Modo Productos");
            cargarProductos();
            configurarBotonesParaProductos();
        }
    }
    
    private void configurarBotonesParaProductos() {
        agregarBton.setOnAction(e -> accionAgregar());
        EditarBoton.setOnAction(e -> EditarBton());
        EliminarBoton.setOnAction(e -> EliminarBton());
    }

    private void configurarBotonesParaPedidos() {
  //      agregarBton.setOnAction(e -> abrirVentanaAgregarPedido());
    //    EditarBoton.setOnAction(e -> editarPedidoSeleccionado());
        EliminarBoton.setOnAction(e -> EliminarBtonP());
    }


    private void cargarProductos() {
    ProductosView.getColumns().clear();

    TableColumn<Object, Integer> colId = new TableColumn<>("ID");
    colId.setCellValueFactory(new PropertyValueFactory<>("id"));

    TableColumn<Object, String> colCod = new TableColumn<>("Código");
    colCod.setCellValueFactory(new PropertyValueFactory<>("codigo"));

    TableColumn<Object, String> colNombre = new TableColumn<>("Producto");
    colNombre.setCellValueFactory(new PropertyValueFactory<>("producto"));

    TableColumn<Object, String> colDescripcion = new TableColumn<>("Descripción");
    colDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));

    TableColumn<Object, String> colEspcs = new TableColumn<>("Especificaciones");
    colEspcs.setCellValueFactory(new PropertyValueFactory<>("especificaciones"));

    TableColumn<Object, BigDecimal> colPC = new TableColumn<>("Precio Compra");
    colPC.setCellValueFactory(new PropertyValueFactory<>("precio_compra"));

    TableColumn<Object, BigDecimal> colPE = new TableColumn<>("Precio Estándar");
    colPE.setCellValueFactory(new PropertyValueFactory<>("precio_estandar"));

    TableColumn<Object, BigDecimal> colPP = new TableColumn<>("Precio Promoción");
    colPP.setCellValueFactory(new PropertyValueFactory<>("precio_promocion"));

    TableColumn<Object, String> colCat = new TableColumn<>("Categoría");
    colCat.setCellValueFactory(new PropertyValueFactory<>("categoria"));

    TableColumn<Object, Integer> colCant = new TableColumn<>("Cantidad");
    colCant.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

    TableColumn<Object, String> colBolsa = new TableColumn<>("Bolsa");
    colBolsa.setCellValueFactory(new PropertyValueFactory<>("bolsa"));

    TableColumn<Object, Boolean> colNuevo = new TableColumn<>("Nuevo");
    colNuevo.setCellValueFactory(new PropertyValueFactory<>("nuevo"));

    TableColumn<Object, String> colProm = new TableColumn<>("Promoción");
    colProm.setCellValueFactory(new PropertyValueFactory<>("promocion"));

    ProductosView.getColumns().addAll(colId, colCod, colNombre, colDescripcion, colEspcs,colPC, colPE, colPP, colCat, colCant, colBolsa, colNuevo, colProm);

    listaProductos = FXCollections.observableArrayList(new ProductosDao().obtenerProductos());
    ProductosView.setItems(listaProductos);
    }

    
    private void cargarPedidos() {
    ProductosView.getColumns().clear();
        ProductosView.getItems().clear();   // limpia los datos actuales

    
    TableColumn<Object, Integer> colId = new TableColumn<>("ID");
    colId.setCellValueFactory(new PropertyValueFactory<>("id"));

    TableColumn<Object, String> colCod = new TableColumn<>("Código");
    colCod.setCellValueFactory(new PropertyValueFactory<>("codigo"));

    TableColumn<Object, String> colProducto = new TableColumn<>("Producto");
    colProducto.setCellValueFactory(new PropertyValueFactory<>("producto"));

    TableColumn<Object, BigDecimal> colPC = new TableColumn<>("Precio Compra");
    colPC.setCellValueFactory(new PropertyValueFactory<>("precioCompra"));

    TableColumn<Object, String> colFecha = new TableColumn<>("Fecha");
    colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));

    TableColumn<Object, Integer> colCant = new TableColumn<>("Cantidad");
    colCant.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

    TableColumn<Object, String> colCliente = new TableColumn<>("Cliente");
    colCliente.setCellValueFactory(new PropertyValueFactory<>("nombreCliente"));

    ProductosView.getColumns().addAll(
        colId, colCod, colProducto, colPC, colFecha, colCant, colCliente
    );

    listaPedidos = FXCollections.observableArrayList(new PedidosDao().obtenerPedidos());
    ProductosView.setItems(listaPedidos);
    }
    
    

    public void actualizarTabla() {
        listaProductos.clear();
        listaProductos.addAll(new ProductosDao().obtenerProductos());
    }
    public void actualizarTablaP() {
        listaPedidos.clear();
        listaPedidos.addAll(new ProductosDao().obtenerProductos());
    }

    @FXML
    private void EditarBton() {
        Producto seleccionado = (Producto) ProductosView.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarAlerta(Alert.AlertType.WARNING, "Selecciona un producto", "Por favor, selecciona una fila antes de editar.");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/betterware/AccionEditarController.fxml"));
            Parent root = loader.load();
            
            EditarController controller = loader.getController();
            controller.setProducto(seleccionado); // 👈 Enviamos el producto seleccionado
            controller.setTablaPrincipalController(this); // Para poder refrescar después

            
            Stage newStage = new Stage();
            newStage.setTitle("Editar");
            newStage.setScene(new Scene(root));
            newStage.setResizable(true);
            newStage.centerOnScreen();
            newStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void FiltroBton() {
        // por implementar
    }

    @FXML
    private void BuscarBton() {
        // por implementar
    }

    @FXML
    private void accionAgregar() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/betterware/AccionAgregarController.fxml"));
            Parent root = loader.load();
     
            AccionAgregarControllerController controller = loader.getController();
            controller.setTablaPrincipalController(this); // 👈 le pasas referencia
            
            Stage newStage = new Stage();
            newStage.setTitle("Agregar");
            newStage.setScene(new Scene(root));
            newStage.setResizable(true);
            newStage.centerOnScreen();
            newStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void EliminarBton() {
        Producto seleccionado = (Producto) ProductosView.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {
        mostrarAlerta(Alert.AlertType.WARNING, "Selecciona un producto", "Por favor, selecciona una fila antes de eliminar.");
        return;
        }
        
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmar eliminación");
        confirm.setHeaderText("¿Eliminar producto?");
        confirm.setContentText("Se eliminará el producto: " + seleccionado.getProducto());

        Optional<ButtonType> resultado = confirm.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            
            ProductosDao dao = new ProductosDao();
            boolean exito = dao.eliminarProducto(seleccionado.getId());

            if (exito) {
                listaProductos.remove(seleccionado);
                mostrarAlerta(Alert.AlertType.INFORMATION, "Eliminado", "El producto fue eliminado correctamente.");
                actualizarTabla();
            } else {
                mostrarAlerta(Alert.AlertType.ERROR, "Error", "No se pudo eliminar el producto.");
            }
        }
    }
    
    @FXML
    private void EliminarBtonP() {
        Pedidos seleccionado = (Pedidos) ProductosView.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {
        mostrarAlerta(Alert.AlertType.WARNING, "Selecciona un producto", "Por favor, selecciona una fila antes de eliminar.");
        return;
        }
        
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmar eliminación");
        confirm.setHeaderText("¿Eliminar producto?");
        confirm.setContentText("Se eliminará el producto: " + seleccionado.getId());

        Optional<ButtonType> resultado = confirm.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            
            PedidosDao dao = new PedidosDao();
            boolean exito = dao.eliminarPedido(seleccionado.getId());

            if (exito) {
                listaPedidos.remove(seleccionado);
                mostrarAlerta(Alert.AlertType.INFORMATION, "Eliminado", "El producto fue eliminado correctamente.");
                actualizarTabla();
                ProductosView.refresh();
            } else {
                mostrarAlerta(Alert.AlertType.ERROR, "Error", "No se pudo eliminar el producto.");
            }
        }
    }
    
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
   
}

