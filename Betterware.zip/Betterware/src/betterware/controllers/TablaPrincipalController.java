/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package betterware.controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author manac
 */
public class TablaPrincipalController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button agregarBton;
    
    @FXML
    private void accionAgregar(){
        try {
            // Cargar el otro FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/betterware/AccionAgregarController.fxml"));
            Parent root = loader.load();

            // Crear la nueva ventana
            Stage newStage = new Stage();
            newStage.setTitle("Tabla Principal");
            newStage.setScene(new Scene(root));
            newStage.setResizable(true);
            newStage.centerOnScreen();
            newStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
}
