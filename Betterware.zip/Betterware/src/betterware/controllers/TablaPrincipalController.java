 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package betterware.controllers;

import betterware.dao.ProductosDao;
import betterware.models.Producto;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class TablaPrincipalController implements Initializable {

    @FXML
    private TableView<Producto> ProductosView;
    @FXML
    private TableColumn<Producto, Integer> colid;
    @FXML
    private TableColumn<Producto, String> colcod;
    @FXML 
    private TableColumn<Producto, String> colproducto;
    @FXML 
    private TableColumn<Producto, String> colDescripcion;
    @FXML 
    private TableColumn<Producto, String> colEspcs;
    @FXML 
    private TableColumn<Producto, String> colPC;    
    @FXML 
    private TableColumn<Producto, String> colPE;
    @FXML 
    private TableColumn<Producto, String> colPP;    
    @FXML 
    private TableColumn<Producto, String> colCat;    
    @FXML 
    private TableColumn<Producto, String> colCant;    
    @FXML 
    private TableColumn<Producto, String> colBolsa;
    @FXML 
    private TableColumn<Producto, String> colNuevo;    
    @FXML
    private TableColumn<Producto, String> colProm;
    
    @FXML
    private Button agregarBton;
    @FXML
    private Button EditarBoton;
    @FXML 
    private Button EliminarBoton;

    private ObservableList<Producto> listaProductos;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarProductos(); // se ejecuta al iniciar
    }
    
    @FXML
    public void cargarProductos() {
        ProductosDao dao = new ProductosDao();
        List<Producto> productos = dao.obtenerProductos();

        listaProductos = FXCollections.observableArrayList(productos);

        colid.setCellValueFactory(new PropertyValueFactory<>("id"));
        colcod.setCellValueFactory(new PropertyValueFactory<>("codigo"));
        colproducto.setCellValueFactory(new PropertyValueFactory<>("producto"));
        colDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        colEspcs.setCellValueFactory(new PropertyValueFactory<>("especificaciones"));
        colPC.setCellValueFactory(new PropertyValueFactory<>("precio_compra"));
        colPE.setCellValueFactory(new PropertyValueFactory<>("precio_estandar"));
        colPP.setCellValueFactory(new PropertyValueFactory<>("precio_promocion"));
        colCat.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        colCant.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        colBolsa.setCellValueFactory(new PropertyValueFactory<>("bolsa"));
        colNuevo.setCellValueFactory(new PropertyValueFactory<>("nuevo"));
        colProm.setCellValueFactory(new PropertyValueFactory<>("promocion"));

        ProductosView.setItems(listaProductos);
    }

    public void actualizarTabla() {
        listaProductos.clear();
        listaProductos.addAll(new ProductosDao().obtenerProductos());
    }

    @FXML
    private void EditarBton() {
            Producto seleccionado = ProductosView.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarAlerta(Alert.AlertType.WARNING, "Selecciona un producto", "Por favor, selecciona una fila antes de editar.");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/betterware/AccionEditarController.fxml"));
            Parent root = loader.load();
            
            EditarController controller = loader.getController();
            controller.setProducto(seleccionado); // 👈 Enviamos el producto seleccionado
            controller.setTablaPrincipalController(this); // Para poder refrescar después

            
            Stage newStage = new Stage();
            newStage.setTitle("Editar");
            newStage.setScene(new Scene(root));
            newStage.setResizable(true);
            newStage.centerOnScreen();
            newStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void FiltroBton() {
        // por implementar
    }

    @FXML
    private void BuscarBton() {
        // por implementar
    }

    @FXML
    private void accionAgregar() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/betterware/AccionAgregarController.fxml"));
            Parent root = loader.load();
     
            AccionAgregarControllerController controller = loader.getController();
            controller.setTablaPrincipalController(this); // 👈 le pasas referencia
            
            Stage newStage = new Stage();
            newStage.setTitle("Agregar");
            newStage.setScene(new Scene(root));
            newStage.setResizable(true);
            newStage.centerOnScreen();
            newStage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void EliminarBton() {
        Producto seleccionado = ProductosView.getSelectionModel().getSelectedItem();
        
        if (seleccionado == null) {
        mostrarAlerta(Alert.AlertType.WARNING, "Selecciona un producto", "Por favor, selecciona una fila antes de eliminar.");
        return;
        }
        
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Confirmar eliminación");
        confirm.setHeaderText("¿Eliminar producto?");
        confirm.setContentText("Se eliminará el producto: " + seleccionado.getProducto());

        Optional<ButtonType> resultado = confirm.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            
            ProductosDao dao = new ProductosDao();
            boolean exito = dao.eliminarProducto(seleccionado.getId());

            if (exito) {
                listaProductos.remove(seleccionado);
                mostrarAlerta(Alert.AlertType.INFORMATION, "Eliminado", "El producto fue eliminado correctamente.");
                actualizarTabla();
            } else {
                mostrarAlerta(Alert.AlertType.ERROR, "Error", "No se pudo eliminar el producto.");
            }
        }
    }
    
    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
        Alert alerta = new Alert(tipo);
        alerta.setTitle(titulo);
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
   
}

